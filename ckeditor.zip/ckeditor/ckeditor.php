<?php
/*
 * CKEditor PHP Class (Simplified)
 * Compatible wrapper for lab exercises
 */

class CKEditor {
    public $basePath = '/ckeditor/';
    public $config = array();

    public function replace($name, $config = array()) {
        $mergedConfig = array_merge($this->config, $config);
        $configJson = json_encode($mergedConfig);
        echo '<script type="text/javascript">';
        echo 'CKEDITOR.replace("' . $name . '", ' . $configJson . ');';
        echo '</script>' . "\n";
    }

    public function replaceAll($config = array()) {
        $mergedConfig = array_merge($this->config, $config);
        $configJson = json_encode($mergedConfig);
        echo '<script type="text/javascript">';
        echo 'CKEDITOR.replaceAll(function(textarea, config) {';
        echo '    var c = ' . $configJson . ';';
        echo '    for (var k in c) config[k] = c[k];';
        echo '    return true;';
        echo '});';
        echo '</script>' . "\n";
    }
}
